const $=id=>document.getElementById(id);
const target=$("target"),menu=$("menu"),start=$("start"),again=$("again"),sound=$("sound"),arena=$("arena");
let score=0,combo=0,time=30,playing=false,timer=null,soundOn=true;
let best=Number(localStorage.getItem("tm_best")||0);
let scores=JSON.parse(localStorage.getItem("tm_scores")||"[]");
$("best").textContent=best;renderBoard();

start.onclick=startGame;again.onclick=startGame;
sound.onclick=()=>{soundOn=!soundOn;sound.textContent=soundOn?"🔊":"🔇"};
target.onclick=hit;

function startGame(){
 score=0;combo=0;time=30;playing=true;
 $("score").textContent=0;$("combo").textContent=0;$("time").textContent=30;
 menu.style.display="none";again.style.display="none";target.style.display="block";
 clearInterval(timer);move();timer=setInterval(()=>{time--; $("time").textContent=time;if(time<=0)finish()},1000);
}
function hit(){
 if(!playing)return;
 score++;combo++;
 if(combo%10===0)score+=5;
 $("score").textContent=score;$("combo").textContent=combo;
 move(); if(soundOn)beep();
}
function move(){
 const s=Math.max(46,76-Math.floor(score/12));
 const x=Math.random()*Math.max(1,arena.clientWidth-s);
 const y=Math.random()*Math.max(1,arena.clientHeight-s);
 target.style.width=s+"px";target.style.height=s+"px";target.style.fontSize=Math.max(22,s/2)+"px";
 target.style.left=x+"px";target.style.top=y+"px";
}
function finish(){
 playing=false;clearInterval(timer);target.style.display="none";again.style.display="block";
 if(score>best){best=score;localStorage.setItem("tm_best",best);$("best").textContent=best}
 scores.push(score);scores.sort((a,b)=>b-a);scores=scores.slice(0,10);
 localStorage.setItem("tm_scores",JSON.stringify(scores));renderBoard();
 const rank=scores.indexOf(score)+1;
 $("rank").textContent="#"+(rank||"—");
 menu.style.display="flex";
 $("menu").innerHTML=`<h2>GAME OVER!</h2><p>Score: <b>${score}</b> &nbsp; Best: <b>${best}</b></p><button class="primary" id="start">PLAY AGAIN</button>`;
 $("start").onclick=startGame;
}
function renderBoard(){
 $("leaders").innerHTML=scores.length?scores.map((s,i)=>`<li>#${i+1} — ${s} points</li>`).join(""):"<li>No scores yet</li>";
}
function beep(){
 try{const a=new(window.AudioContext||window.webkitAudioContext)(),o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=520;g.gain.value=.06;o.start();o.stop(a.currentTime+.045)}catch(e){}
}
