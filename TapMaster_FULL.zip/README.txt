TAP MASTER - FULL STARTER

Files:
- index.html
- style.css
- game.js

Features:
- 30-second game
- Moving target
- Score and combo
- Difficulty increases
- Personal best saved on the device
- Local top-10 leaderboard
- Sound toggle
- Mobile-friendly layout
- Restart/game-over screen

IMPORTANT:
The leaderboard in this version is LOCAL to each device/browser.
It is NOT a real worldwide leaderboard.

For a real global leaderboard, an online backend/database and secure score validation must be added later.
Ads and Play Store publishing should be added only after testing and following the relevant platform policies.
